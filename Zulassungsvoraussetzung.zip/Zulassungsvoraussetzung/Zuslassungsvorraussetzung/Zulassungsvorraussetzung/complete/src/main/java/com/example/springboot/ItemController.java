package com.example.springboot;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import inginf.Item;
import inginf.ItemInstance;

import java.util.List;
import jakarta.servlet.http.HttpSession;

@Controller
public class ItemController {

	@Autowired
	private ApplicationContext context;
    AppStore _AppStore;
    AppStore getAppStore() {
        if (_AppStore == null)
            _AppStore = context.getBean(AppStore.class);
        return _AppStore;
    }

    // Item
    @PostMapping("/items-gui")
    public String createItem(
        Model model,
        HttpSession session,
        @RequestParam Map<String, String> body ) 
    {        
        inginf.Item item = new inginf.Item(
            body.get("Nomenclature"),
            body.get("Description"),
            body.get("Material"));
        if (body.get("WeightedWeight") != null && body.get("WeightedWeight").length() > 0)
            item.setWeightedWeight(Integer.parseInt(body.get("WeightedWeight")));
        if (body.get("CalculatedWeight") != null && body.get("CalculatedWeight").length() > 0)
            item.setCalculatedWeight(Integer.parseInt(body.get("CalculatedWeight")));
        if (body.get("EstimatedWeight") != null && body.get("EstimatedWeight").length() > 0)
            item.setEstimatedWeight(Integer.parseInt(body.get("EstimatedWeight")));
        getAppStore().addNewItem(item);
        model.addAttribute(
                "id", item.Id);
        return "itemCreated";
    }

    // Item Instance erstellen
    @PostMapping("/itemInstance-gui")
    public String createItemInstance(Model model,
        HttpSession session,
        @RequestParam Map <String, String> body ) 
    {
        ItemInstance itemInstance = new ItemInstance  (
        body.get("Name"),
        getAppStore().getItemId((Integer.parseInt(body.get("itemid")))-1));
        Item item = getAppStore().getItemId((Integer.parseInt(body.get("ITEMID")))-1);
        getAppStore().addNewItemInstance(itemInstance);
        item.getUses().add(itemInstance);
            
        return "itemInstanceCreated";
    }

    // Item
    @GetMapping("/items-gui")
    public String createItemDialog() {
        return "itemTemplate";
    }
    
    // Item Instance
    @GetMapping("/itemInstance-gui")
    public String createItemInstanceDialog(Model model) {
        List<Item> items = getAppStore().getItemStore();
        model.addAttribute("items", items);
        return "itemInstanceTemplate";
    } 
    
    // Item
    @GetMapping("/items-gui/list")
    public String listItems(Model model) {
        model.addAttribute(
            "items", 
            getAppStore().getItemStore());
        return "listItems";
    }

    // Item Instance Liste
    @GetMapping("/itemInstance-gui/list")
    public String listItemInstance(Model model) {
        List<ItemInstance> itemInstance = getAppStore().getItemInstanceStore();
        model.addAttribute(
            "itemInstance", itemInstance); 
        return "listItemInstance";
    }
 
    // Item
    @GetMapping("/items-gui/{id}/delete")
    public String deleteItem(@PathVariable int id, Model model) {        
        model.addAttribute(
            "id", id);
        for (Item item : getAppStore().getItemStore())
            if (item.Id == id) {
                getAppStore().getItemStore().remove(item);
                break;
            }
        return "itemDeleted";
    }

    
    // Item Instance löschen
    @GetMapping("/itemInstance-gui/{Name}/delete")
    public String deleteItemInstance(@PathVariable String Name, Model model) {        
        model.addAttribute(
            "Name", Name);
        for (ItemInstance itemInstance : getAppStore().getItemInstanceStore())
            if (itemInstance.getName().equals(Name)) {
                getAppStore().getItemInstanceStore().remove(itemInstance);
                break;
            }
        return "itemInstanceDeleted";
    }
    


    // Item
    @GetMapping("/items-gui/{id}/show")
    public String showItem(@PathVariable int id, Model model) {        
        model.addAttribute(
            "id", id);
        for (Item item : getAppStore().getItemStore())
            if (item.Id == id) {
                model.addAttribute(
                    "item", item);
                break;
            }
        return "showItem";
    }


// Item Instance anzeigen
    @GetMapping("/itemInstance-gui/{Name}/show")
    public String showItemInstance(@PathVariable String Name, Model model) {        
        model.addAttribute(
            "Name", Name);
        for (ItemInstance itemInstance : getAppStore().getItemInstanceStore())
            if (itemInstance.getName().equals(Name)) {
                model.addAttribute(
                    "itemInstance", itemInstance);
                return "showItemInstance";
            }
        return "itemInstanceNotFound";
    }



}
