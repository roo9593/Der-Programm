# spring-item
Beispielanwendung mit dem Springframework zur Darstellung von Produktstrukturen

Basieren auf der Beispielanwendung: https://github.com/spring-guides/gs-spring-boot.git
